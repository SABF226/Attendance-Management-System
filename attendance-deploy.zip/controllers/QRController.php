<?php
class QRController {
    private $db;
    private $sessionModel;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->sessionModel = new AttendanceSession();
    }

    /**
     * GET ?page=qr&action=display&id=X
     * Admin: view/generate the QR code for a session.
     * Adding ?generate=1 forces a new token even if one is active.
     */
    public function display($sessionId) {
        if (($_SESSION['user_role'] ?? '') !== 'admin') {
            header('Location: index.php?page=dashboard');
            exit;
        }

        $session = $this->sessionModel->getById($sessionId);
        if (!$session) {
            $_SESSION['error_message'] = 'Session not found.';
            header('Location: index.php?page=sessions');
            exit;
        }

        // Generate a fresh QR only if the session has never had one, or the admin
        // explicitly asked (so Deactivate persists instead of being re-created).
        // Admin may choose how long the code stays valid (allow-listed minutes).
        if (empty($session['qr_secret']) || isset($_GET['generate'])) {
            $allowedDurations = [5, 15, 30, 60];
            $duration = (int)($_GET['duration'] ?? 30);
            if (!in_array($duration, $allowedDurations, true)) {
                $duration = 30;
            }
            $this->sessionModel->generateQRCode($sessionId, $duration);
            $session = $this->sessionModel->getById($sessionId);
        }

        $pageTitle = 'QR Code – ' . htmlspecialchars($session['session_name']);
        $breadcrumbs = [
            ['label' => 'Sessions', 'url' => 'index.php?page=sessions'],
            ['label' => htmlspecialchars($session['session_name']), 'url' => 'index.php?page=sessions&action=view&id=' . $sessionId],
            ['label' => 'QR Code'],
        ];
        require_once __DIR__ . '/../views/header.php';
        include __DIR__ . '/../views/qr/display.php';
    }

    /**
     * POST ?page=qr&action=deactivate&id=X
     * Admin: manually deactivate the QR code.
     * CSRF is verified globally in index.php.
     */
    public function deactivate($sessionId) {
        if (($_SESSION['user_role'] ?? '') !== 'admin') {
            header('Location: index.php?page=dashboard');
            exit;
        }
        $this->sessionModel->deactivateQRCode($sessionId);
        header('Location: index.php?page=qr&action=display&id=' . $sessionId);
        exit;
    }

    /**
     * POST ?page=qr&action=scan  (JSON body)
     * Member: validate QR token and record attendance.
     * Global CSRF is skipped for this endpoint; token verified from JSON body.
     */
    public function scan() {
        header('Content-Type: application/json');

        if (($_SESSION['user_role'] ?? '') !== 'member') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Member access required']);
            return;
        }

        // Rate limit: max 5 scan attempts per minute per member
        if (!Security::checkRateLimit('qr_scan_' . ($_SESSION['user_id'] ?? ''), 5, 60)) {
            http_response_code(429);
            echo json_encode(['success' => false, 'error' => 'Too many attempts. Please wait a moment.']);
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        if (!is_array($input)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid request']);
            return;
        }

        // Verify CSRF token from JSON body (global check is skipped for this endpoint)
        $csrfToken = $input['csrf_token'] ?? '';
        if (!Security::verifyCsrfToken($csrfToken)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Security token invalid. Please reload the page.']);
            return;
        }

        // The QR encodes the session id and a short-lived rotating token.
        $scanSessionId = (int)($input['sessionId'] ?? 0);
        $token = trim($input['token'] ?? '');
        if ($scanSessionId <= 0 || $token === '') {
            echo json_encode(['success' => false, 'error' => 'No token received']);
            return;
        }

        // Load the session and validate the rotating token against its secret.
        $session = $this->sessionModel->getById($scanSessionId);
        if (!$this->sessionModel->isScanTokenValid($session, $token)) {
            echo json_encode(['success' => false, 'error' => 'QR code is invalid or has expired. Make sure you are scanning the live code shown in class.']);
            return;
        }

        // Geofence: if the session has a pinned location, the member must be near it.
        if ($this->sessionModel->hasGeofence($session)) {
            $lat = $input['lat'] ?? null;
            $lng = $input['lng'] ?? null;
            $acc = $input['accuracy'] ?? 0;
            if ($lat === null || $lng === null || $lat === '' || $lng === '') {
                echo json_encode(['success' => false, 'error' => 'Location required. Allow location access for this site and scan again.']);
                return;
            }
            if (!$this->sessionModel->isWithinGeofence($session, $lat, $lng, $acc)) {
                $dist    = (int)round($this->sessionModel->geofenceDistance($session, $lat, $lng));
                $allowed = (int)round($this->sessionModel->geofenceAllowance($session, $acc));
                echo json_encode(['success' => false, 'error' => "Too far from the class to check in (about {$dist} m away; must be within {$allowed} m). Move closer and scan again."]);
                return;
            }
        }

        $sessionId = (int)$session['id'];
        $memberId  = (int)$_SESSION['user_id'];

        // Prevent duplicate attendance
        $existing = $this->db->query(
            "SELECT id FROM attendance_records WHERE session_id = ? AND member_id = ?",
            [$sessionId, $memberId]
        )->fetch();

        if ($existing) {
            echo json_encode(['success' => false, 'error' => 'Your attendance is already recorded for this session']);
            return;
        }

        // Record attendance
        $this->db->query(
            "INSERT INTO attendance_records (session_id, member_id, status, check_in_time) VALUES (?, ?, 'present', NOW())",
            [$sessionId, $memberId]
        );

        // Award 10 XP
        $this->db->query("UPDATE members SET points = points + 10 WHERE id = ?", [$memberId]);

        $newPoints = (int)$this->db->query("SELECT points FROM members WHERE id = ?", [$memberId])->fetchColumn();

        echo json_encode([
            'success'   => true,
            'message'   => 'Attendance recorded! +10 XP',
            'newPoints' => $newPoints,
        ]);
    }

    /**
     * GET ?page=qr&action=scanner
     * Member: camera scanner page.
     */
    public function scannerPage() {
        if (($_SESSION['user_role'] ?? '') !== 'member') {
            header('Location: index.php?page=dashboard');
            exit;
        }
        $pageTitle = 'Scan QR Code';
        require_once __DIR__ . '/../views/header.php';
        include __DIR__ . '/../views/qr/scanner.php';
    }

    /**
     * GET ?page=qr&action=token&id=X  (JSON)
     * Admin: returns the current rotating token for the session's display screen
     * to poll, so the visible QR refreshes without a full page reload.
     */
    public function token($sessionId) {
        header('Content-Type: application/json');

        if (($_SESSION['user_role'] ?? '') !== 'admin') {
            http_response_code(403);
            echo json_encode(['active' => false, 'error' => 'Admin access required']);
            return;
        }

        $session = $this->sessionModel->getById($sessionId);
        $token = $session ? $this->sessionModel->currentToken($session) : null;

        if ($token === null) {
            echo json_encode(['active' => false]);
            return;
        }

        echo json_encode([
            'active'    => true,
            'sessionId' => (int)$session['id'],
            'token'     => $token,
            'step'      => AttendanceSession::QR_STEP_SECONDS,
            'expiresAt' => $session['qr_code_expires_at'],
        ]);
    }

    /**
     * POST ?page=qr&action=geofence&id=X  (form-encoded)
     * Admin: pin (mode=set, with lat/lng/radius captured from the admin's device)
     * or remove (mode=clear) the session's class location. CSRF is verified
     * globally in index.php.
     */
    public function geofence($sessionId) {
        header('Content-Type: application/json');

        if (($_SESSION['user_role'] ?? '') !== 'admin') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Admin access required']);
            return;
        }

        $session = $this->sessionModel->getById($sessionId);
        if (!$session) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Session not found']);
            return;
        }

        $mode = $_POST['mode'] ?? 'set';

        if ($mode === 'clear') {
            $this->sessionModel->clearGeofence($sessionId);
            echo json_encode(['success' => true, 'geofence' => false]);
            return;
        }

        $lat = $_POST['lat'] ?? '';
        $lng = $_POST['lng'] ?? '';
        $radius = (int)($_POST['radius'] ?? 100);
        $accuracy = (int)round((float)($_POST['accuracy'] ?? 0));
        if ($lat === '' || $lng === '') {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Could not read your location. Allow location access and try again.']);
            return;
        }
        // Reject imprecise pins: an accuracy of hundreds of metres means GPS is off
        // and the browser used IP-based location (often tens of km wrong), which
        // would make the geofence useless. GPS pins are typically ±5–50 m.
        if ($accuracy > 0 && $accuracy > 300) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Your location is only accurate to ±{$accuracy} m — GPS is probably off, so the browser used your internet (IP) location. Turn on GPS and pin from a phone standing in the classroom."]);
            return;
        }
        if (!$this->sessionModel->setGeofence($sessionId, $lat, $lng, $radius, $accuracy)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid coordinates']);
            return;
        }

        echo json_encode(['success' => true, 'geofence' => true, 'radius' => max(20, min(2000, $radius))]);
    }
}
